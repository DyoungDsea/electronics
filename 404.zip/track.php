<?php
//Track user page
$_SESSION['current'] = $_SERVER['REQUEST_URI'];

?>