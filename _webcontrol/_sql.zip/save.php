<?php
echo 
$vcode = 'TOB-'.date("ysm").'U'.date("sh").'-S';