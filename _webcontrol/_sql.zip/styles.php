  <meta name="description" content="">
  <meta name="author" content="">

  <title>Universal Electronics | Admin Dashboard</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <!-- <link href="dataTables.bootstrap4.css" rel="stylesheet"> -->
  <link href="css/sb-admin.css" rel="stylesheet">
  <link href="../css/sweetalert2.min.css" rel="stylesheet">
  <link href="../css/toastr.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="../images/favi.gif">  
  <!-- <link rel="icon" href="../assets/images/slider/logow.png"> -->
  <link rel="stylesheet" href="../datepicker/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">
  <!-- <link rel="stylesheet" type="text/css" href="DataTables/css/dataTables.bootstrap4.min.css"/> -->
  <style>
 
input[type='number'] {
    -moz-appearance:textfield;
}
input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
#content-wrapper{
  margin-top:50px;
}
.carousel-item img{
  height:400px;
  width:400px;
}
.carousel-inner{
  height:400px;
  width:400px;
}
.carousel{
  height:400px;
  width:400px;
}
.carousel-indicators li{
  background:red;
}
.tasha span{
  font-weight:bold;
  margin-right:20px;
}
  </style>